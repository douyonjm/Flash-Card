//
//  Model.swift
//  spellx
//
//  Created by Mackenzy Douyon on 1/12/19.
//  Copyright © 2019 Douyon. All rights reserved.
//

import Foundation
import UIKit
import GameKit

struct RandomButtonTitle {
    var arrayPictures = ["Lifting","Hugging","Exciting","Dropping","Huge","late","rice","climb","clip","mask","twin","hard","horse","born"]
    
    func randomLabel() -> String {
        let random = GKRandomSource.sharedRandom().nextInt(upperBound:arrayPictures.count )
        return arrayPictures[random]
    }
    
}
//    func previousPicture(){
//        if pictureNumber > 0 {
//            imagesForSpelling.image = UIImage(named: arrayPictures[pictureNumber - 1])
//           pictureNumber -= 1
//
//            wordNumber -= 1
//        }}

/* Lifting, patch  displays randomly from arrayPictures as intended. Hugging just display the current picture value
 
 for (i, button) in categoriesButtonLabels.enumerated() {
 button.setTitle("\(categories[i])", for: .normal)
 }
 shuffle Questions and Answers (pictures array)?
 */

var arrayPictures = ["Lifting","talk","Hugging","smile","Exciting","Dropping","fine","mice","nose","page","Space","size","talk","Huge","late","blaze","rice","climb","vote","race","zero","clip","mask","breeze","stream","twin","state","that","patch","what","wish","when","math","farm","corn","score","chore1","porch","chore","part","hard","horse","more","born","before","smart"]
