//
//  ViewController.swift
//  
//
//  Created by Mackenzy Douyon on 11/8/18.
//  Copyright © 2018 Douyon. All rights reserved.
//
import UIKit
//work i naming
class ViewController: UIViewController {
    @IBOutlet weak var imagesForSpelling: UIImageView!
    @IBOutlet weak var choiceOneLabel: UIButton!
    @IBOutlet var labelToShuffle: [UIButton]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        displayRandomButtonTitle()
    }
    
   private var pictureNumber = 0
    //MARK: - struct,  set random tittle for  two buttons
    let randomButtonTitle = RandomButtonTitle()
    //let number = Int(arc4random_uniform(3))
    
    @IBAction func choiceOne(_ sender: UIButton) {
        displayRandomButtonTitle()
        if pictureNumber < randomButtonTitle.arrayPictures.count {
            imagesForSpelling.image = UIImage(named: randomButtonTitle.arrayPictures[pictureNumber])
            pictureNumber += 1
        }
    }
   
    func displayRandomButtonTitle(){
        //viewDidLoad
        imagesForSpelling.image = UIImage.init(named: randomButtonTitle.arrayPictures[0])
        choiceOneLabel.setTitle(randomButtonTitle.arrayPictures[0], for: .normal)
        
        if pictureNumber < randomButtonTitle.arrayPictures.count {
        
            for labelsToShuffle in labelToShuffle {
               _ = [
                    //correct answer
                choiceOneLabel.setTitle(randomButtonTitle.arrayPictures[pictureNumber], for: .normal),
                //other buttons
                labelsToShuffle.setTitle(randomButtonTitle.randomLabel(), for: .normal)]
                
              //try to shuffle correct answer with..
//choiceOneLabel.setTitle(buttons.shuffled(), for: .normal)

            }
            
        }
    }
    
}

